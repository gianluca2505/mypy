from FCM import FCM

class FCMS(FCM):

    def __init__(self, img, c, maxIterations, m, p, q, e, dim, errorType):
        """Costruttore. Richiama il costruttore di Clustering.

            :param img: np.array
                matrice dei pixel dell'immagine da clusterizzare
            :param c: int
                numero di cluster
            :param maxIterations: int
                numero massimo di iterazioni dell'algoritmo
            :param m: float
                "fuzzyness" dell'algoritmo
            :param e: float
                errore minimo.
            :param errorType: int
                tipo di errore
        """
        self.dim = dim
        self.p = p
        self.q = q
        FCM.__init__(self, img, c, maxIterations, m, e, errorType) # Chiama costruttore sovraclasse

    def calculateMembership(self):
        """Override. Calcola la matrice di membership a partire dai valori dei centroidi."""

        # Per ogni cluster e ogni data point
        for k in range(self.c):
            for h in range(self.height):
                for w in range(self.width):

                    # Prende un pixel
                    aPixel = self.img[w][h]

                    # Distanza tra un pixel e il cluster k-esimo
                    top = self.calcDistance(aPixel, self.centroids[k])
                    #print("Top: " + str(top))
                    # Bottom e' la somma delle distanze da questo data point a tutti i centroidi
                    sumTerms = 0.0

                    for ck in range(self.c):
                        thisDistance = self.calcDistance(aPixel, self.centroids[ck])
                        sumTerms += pow((top / thisDistance), (2.0 / (self.m - 1.0)))

                    self.membership[w][h][k] = (1.0 / sumTerms)

                    # Calcolo membership con funzione spaziale
                    top = pow(self.membership[w][h][k], self.p) * pow(self.spatialFunction(w, h, k), self.q)

                    bottom = 0.0
                    for ck in range(self.c):
                        bottom += pow(self.membership[w, h, ck], self.p) * pow(self.spatialFunction(w, h, ck), self.q)

                    #print("Top: " + str(top) + " Bottom: " + str(bottom))
                    self.membership[w][h][k] = top / bottom # Aggiorna membership


    def spatialFunction(self, w, h, k):
        # Funzione spaziale
        spatialFun = 0.0
        window = self.findWindow(w, h, self.dim)

        for i in range(len(window)):
            x = window[i][0]
            y = window[i][1]
            spatialFun += self.membership[x][y][k]

        return spatialFun

