import FCM
from numpy import *

class SFCM_1(FCM.FCM):
    def __init__(self, img, c, maxIterations, m, e, alfa, dim, errorType):
        """Costruttore. Richiama il costruttore di Clustering.

            :param img: np.array
                matrice dei pixel dell'immagine da clusterizzare
            :param c: int
                numero di cluster
            :param maxIterations: int
                numero massimo di iterazioni dell'algoritmo
            :param m: float
                "fuzzyness" dell'algoritmo
            :param e: float
                errore minimo.
            :param alfa: float
                peso del vincolo spaziale
            :param dim: int
                dimensione della finestra
            :param errorType: int
                tipo di errore
        """

        self.alfa = alfa
        self.dim = dim

        FCM.FCM.__init__(self, img, c, maxIterations, m, e, errorType) # Chiama costruttore sovraclasse


    def calculateMembership(self):
        """Override. Calcola la matrice di membership a partire dai valori dei centroidi."""

        # Crea un nuovo oggetto matrice membership
        self.membership = [ [[ 0.0 for k in range(self.c) ] for h in range(self.height) ] for w in range(self.width) ]
        self.membership = array(self.membership)

        # Per ogni cluster e ogni data point
        for k in range(self.c):
            for h in range(self.height):
                for w in range(self.width):

                    # Top
                    aPixel = self.img[w][h] # Prende un pixel

                    # Distanza tra un pixel e il cluster k-esimo
                    top1 = pow(self.calcDistance(aPixel, self.centroids[k]), 2.0)

                    # Calcola media/mediana finestra (per ciascun canale)
                    mean = self.calculateFilteredPixel(w, h)

                    top2 = self.alfa * (pow(self.calcDistance(mean, self.centroids[k]), 2.0))

                    top = pow((top1 + top2), (-1.0 / (self.m - 1.0))) # Top

                    # Bottom
                    bottom = 0.0
                    for ck in range(self.c):
                        bottom1 = pow(self.calcDistance(aPixel, self.centroids[ck]), 2.0)

                        bottom2 = self.alfa * pow(self.calcDistance(mean, self.centroids[ck]), 2.0)

                        bottom += pow((bottom1 + bottom2), (-1.0 / (self.m - 1.0)))

                    self.membership[w][h][k] = top / bottom # Aggiorna membership


    def calculateClusterCenters(self):
        """Override. Calcola i centroidi a partire dalla matrice di membership."""

        for k in range(self.c):

            # Numeratore
            top = 0.0
            bottom = 0.0

            for h in range(self.height):
                for w in range(self.width):
                    top1 = pow(self.membership[w][h][k], self.m)

                    # Calcola media/mediana
                    mean = self.calculateFilteredPixel(w, h)

                    top2 = self.img[w][h] + self.alfa * mean

                    top += top1 * top2

                    # Denominatore
                    bottom += top1

            bottom = (1.0 + self.alfa) * bottom

            self.centroids[k] = top / bottom


    def calculateFilteredPixel(self, w, h):
        # Calcola media finestra (per ciascun canale)
        window = self.findWindow(w, h, self.dim)
        mean = [ 0.0 for i in range(self.nChannels) ]
        for i in range(len(window)):
            x = window[i][0]
            y = window[i][1]
            mean += self.img[x][y]

        mean = mean / len(window)

        return mean
