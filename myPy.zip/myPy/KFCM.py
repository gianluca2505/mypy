from KernelizedClustering import KernelizedClustering

from numpy import *

class KFCM(KernelizedClustering):
    """Implementa l'algoritmo Kernelized fuzzy c-means"""

    def __init__(self, img, c, maxIterations, m, sigma, e, errorType):
        """Costruttore. Chiama costruttore superclasse"""

        KernelizedClustering.__init__(self, img, c, maxIterations, m, sigma, e, errorType) # Chiama costruttore sovraclasse


    def calculateMembership(self):
        """Override. Calcola la matrice di membership a partire dai centroidi tramite Kernel"""

        # Crea un nuovo oggetto matrice membership
        self.membership = [ [[ 0.0 for k in range(self.c) ] for h in range(self.height) ] for w in range(self.width) ]
        self.membership = array(self.membership)

        # Per ogni cluster e ogni data point
        for k in range(self.c):
            for h in range(self.height):
                for w in range(self.width):

                    # Prende un pixel
                    aPixel = self.img[w][h]
                    kernel = self.kernel(aPixel, self.centroids[k])

                    top = pow((1.0 - kernel), (-1.0 / (self.m - 1.0)))


                    # Bottom e' la somma delle distanze da questo data point a tutti i centroidi
                    bottom = 0.0

                    for ck in range(self.c):
                        kernel = self.kernel(aPixel, self.centroids[ck])
                        bottom += (1.0 - kernel) ** (-1.0 / (self.m - 1.0))

                    self.membership[w][h][k] = top / bottom


