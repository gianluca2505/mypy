from ProgressBar import Ui_ProgressWindow
from PyQt5 import QtCore, QtGui
import sys


class Progress(QtGui.QMainWindow, Ui_ProgressWindow):
      def __init__(self, parent=None):
            QtGui.QWidget.__init__(self, parent)
            self.setupUi(self)

      def main(self):
            self.show()

      def progress(self, completed):
            self.progressBar.setValue(completed)

      def quit(self):
            self.close()


if __name__=='__main__':
      app = QtGui.QApplication(sys.argv)
      form = Progress()
      form.main()
      app.exec_()

