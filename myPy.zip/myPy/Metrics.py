# -*- coding: utf-8 -*-
from numpy import *
from math import *
import copy

class Metrics(object):
    """Implementa le misure di accuratezzza per la segmentazione"""

    def __init__(self, segmentedImage, corrSegmentedImage, k, nClasses, membership):
        """Costruttore.Imposta l'immagine di cui calcolare l'accuratezza.

            :param segmentedImage: np.array
                l'immagine segmentata tramite un algoritmo
            :param corrSegmentedImage: np.array
                l'immagine correttamente segmentata
            :param k: int
                il numero di cluster
            :param nClasses: int
                il numero delle classi nell'immagine correttamente segmentata
            :param membership: np.array
               l'ultima matrice di membership ottenuta tramite l'algoritmo scelto
        """

        # Acquisizione informazioni sull'immagine
        self.k = k
        self.nClasses = nClasses
        self.membership = membership

        # Preleva l'informazione sui i pixel correttamente classificati per classe
        self.classesClusters = self.__getMetricsInformation(segmentedImage, corrSegmentedImage, k)

        self.width=len(segmentedImage[0])
        self.height=len(segmentedImage)


    def __getMetricsInformation(self, segmentedImage, corrSegmentedImage, k):
        """Predispone una struttura per contenere le informazioni necessarie a calcolare l'accuratezza della segmentazione.

            :param segmentedImage: np.array
                l'immagine segmentata con l'algoritmo scelto
            :param corrSegmentedImage: np.array
                l'immagine correttamente segmentata
            :param k: int
                il numero di cluster

            :return: classesClusters: list(Metric())
                una struttura dati che matiene le corrispondenze tra i cluster individuati e le classi dell'immagine
                correttamente segmentata
        """

        # Predisponiamo un vettore che contiene tutte le posizioni dei pixel
        # appartenenti ad un determinato cluster
        cluster = [ [ ] for j in range(k) ]
        classes = [] # Memorizza coppie (Chiave, Quantita'), con quantita' di pixel per ogni Classe
        for i in range(len(segmentedImage)):
            for j in range(len(segmentedImage[i])):
                index = segmentedImage[i][j]
                cluster[index].append([i, j])

                index = corrSegmentedImage[i][j]

                # Aggiunge la classe alla lista. Se esiste, aggiorna la quantita'
                exists = False
                for w in range(len(classes)):
                    if (classes[w][0] == index):
                        classes[w][1] += 1 # Aggiorna quantita' di pixel di quella classe
                        exists = True

                if (exists == False):
                    classes.append([index, 1]) # Inserisce nome classe e il numero pixel = 1


        nClasses = len(classes)
        classesClusters = [ Metric() for h in range(k) ] # Struttura che mantiene le corrispondenze tra cluster e classi
        for i in range(k):
            # Struttura che mantiene il numero di pixel per ogni classe nelle posiz. dei pixel del cluster corr.
            classCluster = [ 0 for h in range(nClasses) ]

            for j in range(len(cluster[i])):
                # Acquisisce posizione pixel nel cluster
                x = cluster[i][j][0]
                y = cluster[i][j][1]
                # Acquisisce classe effettiva in quella posizione
                index = corrSegmentedImage[x][y]
                classCluster[index] += 1 # Memorizza quantita' di pixel di quella classe per le posizioni del cluster i

            # Trova la classe piu' frequente nelle posizioni dei pixel del cluster
            maxIndex = 0
            for j in range(len(classCluster)):
                if (classCluster[j] > classCluster[maxIndex]):
                    maxIndex = j

            classesClusters[i].couple = (maxIndex, i) # Coppia (classe, cluster)
            classesClusters[i].qtClass = classes[maxIndex][1] # Q.ta' pixel nella classe piu' freq.
            classesClusters[i].qtMatchCC = classCluster[maxIndex] # Q.ta' corrispondenze
            classesClusters[i].qtCluster = len(cluster[i]) # Q.ta' pixel nel cluster
            classesClusters[i].qtMatchWithAllClasses = copy.deepcopy(classCluster) # Numero di pixel coincidenti tra il cluster i e tutte le classi

        return classesClusters

    def __getMetricsInformation2(self, segmentedImage, corrSegmentedImage, k):
        """Predispone una struttura per contenere le informazioni necessarie a calcolare l'accuratezza della segmentazione.

            :param segmentedImage: np.array
                l'immagine segmentata con l'algoritmo scelto
            :param corrSegmentedImage: np.array
                l'immagine correttamente segmentata
            :param k: int
                il numero di cluster

            :return: classesClusters: list(Metric())
                una struttura dati che matiene le corrispondenze tra i cluster individuati e le classi dell'immagine
                correttamente segmentata
        """

        # Predisponiamo un vettore che contiene tutte le posizioni dei pixel
        # appartenenti ad un determinato cluster
        cluster = [ [ ] for j in range(k) ]
        classes = [] # Memorizza coppie (Chiave, Quantita'), con quantita' di pixel per ogni Classe
        for i in range(len(segmentedImage)):
            for j in range(len(segmentedImage[i])):
                index = segmentedImage[i][j]
                cluster[index].append([i, j])

                index = corrSegmentedImage[i][j]

                # Aggiunge la classe alla lista. Se esiste, aggiorna la quantita'
                exists = False
                for w in range(len(classes)):
                    if (classes[w][0] == index):
                        classes[w][1] += 1 # Aggiorna quantita' di pixel di quella classe
                        exists = True

                if (exists == False):
                    classes.append([index, 1]) # Inserisce nome classe e il numero pixel = 1


        nClasses = len(classes)
        classesClusters = [ Metric() for h in range(k) ] # Struttura che mantiene le corrispondenze tra cluster e classi
        for i in range(k):
            # Struttura che mantiene il numero di pixel per ogni classe nelle posiz. dei pixel del cluster corr.
            classCluster = [ 0 for h in range(nClasses) ]

            for j in range(len(cluster[i])):
                # Acquisisce posizione pixel nel cluster
                x = cluster[i][j][0]
                y = cluster[i][j][1]
                # Acquisisce classe effettiva in quella posizione
                index = corrSegmentedImage[x][y]
                classCluster[index] += 1 # Memorizza quantita' di pixel di quella classe per le posizioni del cluster i

            # Trova la classe piu' frequente nelle posizioni dei pixel del cluster
            maxIndex = 0
            for j in range(len(classCluster)):
                if (classCluster[j] > classCluster[maxIndex]):
                    maxIndex = j

            classesClusters[i].couple = (maxIndex, i) # Coppia (classe, cluster)
            classesClusters[i].qtClass = classes[maxIndex][1] # Q.ta' pixel nella classe piu' freq.
            classesClusters[i].qtMatchCC = classCluster[maxIndex] # Q.ta' corrispondenze
            classesClusters[i].qtCluster = len(cluster[i]) # Q.ta' pixel nel cluster
            classesClusters[i].qtMatchWithAllClasses = copy.deepcopy(classCluster) # Numero di pixel coincidenti tra il cluster i e tutte le classi


        return classesClusters

    def getClassesClusters(self):
        """Restituisce la struttura ClussesClusters.

            :return: ClassesClusters list(Metric())
                una struttura dati contenente le corrispondenze tra claster e classsi con relative metriche.
        """

        return self.classesClusters

    def calculateAccuracy(self):
        """ Calcola l'accuratezza totale.

            :return: accuracy:float
                l'accuratezza totale
        """

        totalElem=0
        # Calcola quantita' di pixel correttamente classificati
        nCorrClassified = 0
        for i in range(len(self.classesClusters)):
            nCorrClassified += self.classesClusters[i].qtMatchCC
            totalElem += self.classesClusters[i].qtCluster # Calcola dimensione dataset

        #totPixel = self.width * self.height

        # Calcola accuratezza totale
        accuracy = (float(sum(nCorrClassified)) / float(totalElem))

        return accuracy

    def calculateJaccardIndex(self):
        """Calcola l'indice di similarità di jaccard tra ciascuna classe e il cluster associato

            :return: accuracyClass: list
            la lista degli indici di Jaccard per ciascuna classe. La posizione nella lista corrisponde al numero del
            cluster.
        """

        # Calcola indici di Jaccard per ciascuna classe
        jaccardIndex = [ 0 for h in range(self.k) ]

        for i in range(self.k):
            # Unione pixel classificati in Classe i-esima
            unionClass = (self.classesClusters[i].qtCluster + self.classesClusters[i].qtClass) - self.classesClusters[i].qtMatchCC
            jaccardIndex[i] = float(self.classesClusters[i].qtMatchCC) / unionClass
            jaccardIndex[i] = '%.4f'%jaccardIndex[i]

        return jaccardIndex

    def calculateEntropy(self):
        """Calcola l'entropia di ciacun cluster

            :return: entropy: list
            la lista contenente le entropie per ciascun cluster. La posizione nella lista corrisponde al numero del
            cluster.
        """

        entropy = [] # Insieme delle entropie
        for i in range(self.k):
            singleEntropy = 0.0
            for j in range(self.nClasses):
                if (self.classesClusters[i].qtCluster != 0):
                    # |Cluster i-esimo Intersez. Classe j-esima| / |Cluster i-esimo|
                    pr = float(self.classesClusters[i].qtMatchWithAllClasses[j]) / float(self.classesClusters[i].qtCluster)
                    #pr = (Decimal(self.classesClusters[i].qtMatchWithAllClasses[j])) / Decimal(self.classesClusters[i].qtCluster)

                    if (pr != 0):
                        singleEntropy += pr * log(pr, 2) # Calcola entropia

            entropy.append(round(-1 * singleEntropy,4)) # Aggiungi entropia alla lista

        return entropy

    def calculateTotalEntropy(self):
        """Calcola l'entropia totale

            :return: entropy:float
                l'entropia totale
        """

        entropy = 0.0
        totalElem = 0
        clusterEntropy = self.calculateEntropy()

        for i in range(self.k):
            a = self.classesClusters[i].qtCluster # Cardinalita' i-esimo cluster
            totalElem += self.classesClusters[i].qtCluster # Calcola dimensione dataset

            entropy += a * clusterEntropy[i]

        entropy = entropy / totalElem
        return entropy

    def calculatePurity(self):
        """Calcola la purezza di ogni singolo cluster

            :return: purity:list
            la lista delle purezze di tutti i cluster. La posizione nella lista corrisponde al numero del cluster.
        """

        purity = []
        for i in range(self.k):
            max = 0
            for j in range(self.nClasses):
                # Calcola purezza singola
                if (self.classesClusters[i].qtCluster != 0):
                    p = float(self.classesClusters[i].qtMatchWithAllClasses[j]) / float(self.classesClusters[i].qtCluster)
                    # Prendi purezza massima
                    if (p > max):
                        max = p

            purity.append(round(max,4))

        return purity

    def calculateTotalPurity(self):
        """Calcola la purezza totale

            :return: purity:float
                la purezza totale
        """

        purity = 0.0
        totalElem = 0
        clusterPurity = self.calculatePurity()

        for i in range(self.k):
            a = self.classesClusters[i].qtCluster # Cardinalita' i-esimo cluster
            totalElem += self.classesClusters[i].qtCluster # Calcola dimensione dataset

            purity += a * clusterPurity[i]

        purity = purity / totalElem

        return purity

    # Calcola precision
    def calculatePrecision(self):
        """Calcola la la precision per ogni singolo cluster

            :return: precision:list
            la lista delle precision di tutti i cluster. La posizione nella lista corrisponde al numero del cluster.
        """

        # TP / TP + FP
        precision = []
        for i in range(self.k):
            if (self.classesClusters[i].qtCluster != 0):
                p = float(self.classesClusters[i].qtMatchCC) / float(self.classesClusters[i].qtCluster)
            else:
                p = 0

            precision.append(round(p,4))

        return precision

    # Calcola recall
    def calculateRecall(self):
        """Calcola la la recall per ogni singolo cluster

            :return: recall:list
            la lista delle recall di tutti i cluster. La posizione nella lista corrisponde al numero del cluster.
        """

        # Recall = TP / TP + FN
        recall = []
        for i in range(self.k):
            r = float(self.classesClusters[i].qtMatchCC) / float(self.classesClusters[i].qtClass)
            recall.append(round(r,4))

        return recall

    # Calcola F-score
    def calculateFScore(self):
        """Calcola la l'FScore per ogni singolo cluster

            :return: fscore:list
            la lista degli FScore di tutti i cluster. La posizione nella lista corrisponde al numero del cluster.
        """
        p = array(self.calculatePrecision())
        r = array(self.calculateRecall())

        fscore = []
        for i in range(self.k):
            if ((p[i] + r[i]) != 0):
                f = (2 * p[i] * r[i]) / (p[i] + r[i])
                fscore.append(round(f,4))
            else:
                fscore.append(0.0)

        return fscore

    '''
    def calculateClusterArea(self):
        """Stima l'area di ogni singolo cluster a partire dalla matrice di membership.

            :return: clusterAreas:list
            la lista delle aree di tutti i cluster. La posizione nella lista corrisponde al numero del cluster.
        """
        clusterAreas = [ 0.0 for i in range(self.k) ]

        for i in range(self.height):
            for j in range(self.width):
                for c in range(self.k):
                    clusterAreas[c] += self.membership[i][j][c]

            n = self.width * self.height
            clusterAreas[c] = (clusterAreas[c] / n) * 100

        return clusterAreas
    '''

class Metric:
    """Struttura dati che contiene le corrispondenze tra classi e cluster necessarie al calcolo delle metriche."""

    couple = None
    """Coppia (classe, cluster)"""
    qtClass = 0
    """# Q.ta' pixel nella classe piu' freq."""
    qtMatchCC = 0
    """Q.ta' corrispondenze"""
    qtCluster = 0
    """Q.ta' pixel nel cluster"""
    qtMatchWithAllClasses = []
    """Numero di pixel coincidenti tra il cluster i e tutte le classi"""

