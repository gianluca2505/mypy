from KernelizedClustering import KernelizedClustering
import copy

class SKFCM(KernelizedClustering):
    """Implementa l'algoritmo Spatially constrained Kernelized Fuzzy C-means"""

    def __init__(self, img, c, maxIterations, m, sigma, e, alfa, dim, errorType):
        """Costruttore. Estende costruttore superclasse con nuovi parametri.

            :param img: np.array
                la matrice rappresentante l'immagine da clusterizzare
            :param c: int
                il numero di cluster da trovare
            :param maxIterations: int
                il numero massimo di iterazioni dell'algoritmo
            :param m: float
                la "fuzzyness" dell'algoritmo
            :param e: float
                l'errore minimo. Una delle condizioni di stop dell'algoritmo.
            :param alfa: float
                peso del vincolo spaziale
            :param dim: int
                dimensione finestra
        """
        KernelizedClustering.__init__(self, img, c, maxIterations, m, sigma, e, errorType) # Chiama costruttore sovraclasse

        self.alfa = alfa
        self.dim = dim


    def calculateMembership(self):
        """Override. Calcola la matrice di membersip a partire dai centroidi tramite Kernel"""
        precMembership = copy.deepcopy(self.membership)

        # Per ogni cluster e ogni data point
        for h in range(self.height):
            for w in range(self.width):

                for k in range(self.c):
                    # Prende un pixel
                    aPixel = self.img[w][h]
                    kernel = self.kernel(aPixel, self.centroids[k])

                    # Top
                    top1 = (1.0 - kernel)

                    # Trova la finestra del pixel in posizione [w,h]
                    window = self.findWindow(w, h, self.dim)
                    nr = len(window)

                    #print("window: " + str(window) + " Pixel: " + str(w) + "; " + str(h))
                    top2 = 0.0
                    for i in range(nr):
                        x = window[i][0]
                        y = window[i][1]
                        top2 += pow((1.0 - precMembership[x][y][k]), self.m)
                    top2 = (self.alfa * top2) / float(nr)

                    top = pow((top1 + top2), (-1.0 / (self.m - 1.0)))

                    # Bottom
                    bottom = 0.0

                    for ck in range(self.c):
                        kernel = self.kernel(aPixel, self.centroids[ck])
                        b1 = (1.0 - kernel)

                        b2 = 0.0
                        for i in range(nr):
                            x = window[i][0]
                            y = window[i][1]
                            b2 += pow((1.0 - precMembership[x][y][ck]), self.m)
                        b2 = self.alfa * b2 / float(nr)

                        bottom += pow((b1 + b2),(-1.0 / (self.m - 1.0)))

                    self.membership[w][h][k] = top / bottom