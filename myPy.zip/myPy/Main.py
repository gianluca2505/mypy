# coding=utf-8
from design import Ui_MainWindow
from KMeans import KMeans
from FCM import FCM
from FCMS import FCMS
from SFCM import SFCM
from SFCM_1 import SFCM_1
from SFCM_2 import SFCM_2
from KFCM import KFCM
from SKFCM import SKFCM
from Result import *
from PyQt5 import QtCore, QtGui
import numpy as np
import sys
import shutil
import os.path

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class MainWindow(QtGui.QMainWindow, Ui_MainWindow):
      def __init__(self, parent=None):
            QtGui.QWidget.__init__(self, parent)
            self.setupUi(self)
            self.f = None
            self.filename=None
            self.codeim=None
            self.sse=None
            self.xie=None
            self.entropy_memb=None
            self.c = 0
            self.okButton.clicked.connect(self.openResult)
            os.makedirs("../Progetto Tesi/output")

      def settingsKM(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)

            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setScaledContents(True)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(3)
            self.setting3a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QComboBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("Error Threshold")
            self.setting4.setText("Error Type")

            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 0.001)
            self.setting4a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting4a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting4a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting4a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting4a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

            return self.setting1a, self.setting2a, self.setting3a, self.setting4a

      def settingsFCM(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)

            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setScaledContents(True)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(3)
            self.setting3a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(1)
            self.setting4a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)
            self.gridLayout.addWidget(self.groupBox_2, 3, 0, 2, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QComboBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.addItem(_fromUtf8(""))
            self.setting5a.addItem(_fromUtf8(""))
            self.setting5a.addItem(_fromUtf8(""))
            self.setting5a.addItem(_fromUtf8(""))
            self.setting5a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("Error Threshold")
            self.setting4.setText("m")
            self.setting5.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 0.001)
            self.setting4a.setProperty("value", 2.0)
            self.setting5a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting5a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting5a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting5a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting5a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

      def settingsFCMS(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)

            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)
            self.gridLayout.addWidget(self.groupBox_2, 3, 0, 2, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(3)
            self.setting3a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(1)
            self.setting4a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setSingleStep(2)
            self.setting5a.setMinimum(1)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.setDecimals(1)
            self.setting6a.setMaximum(1.0)
            self.setting6a.setMinimum(0.1)
            self.setting6a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.setting7 = QtGui.QLabel(self.groupBox_2)
            self.setting7.setObjectName(_fromUtf8("setting7"))
            self.gridLayout_3.addWidget(self.setting7, 7, 0, 1, 1)
            self.setting7a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting7a.setObjectName(_fromUtf8("setting7a"))
            self.setting7a.setDecimals(1)
            self.setting7a.setMaximum(1.0)
            self.setting7a.setMinimum(0.1)
            self.setting7a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting7a, 7, 1, 1, 1)

            self.setting8 = QtGui.QLabel(self.groupBox_2)
            self.setting8.setObjectName(_fromUtf8("setting8"))
            self.gridLayout_3.addWidget(self.setting8, 8, 0, 1, 1)
            self.setting8a = QtGui.QComboBox(self.groupBox_2)
            self.setting8a.setObjectName(_fromUtf8("setting8a"))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting8a, 8, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("Error Threshold")
            self.setting4.setText("m")
            self.setting5.setText("Dim")
            self.setting6.setText("p")
            self.setting7.setText("q")
            self.setting8.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 0.001)
            self.setting4a.setProperty("value", 2.0)
            self.setting5a.setProperty("value", 3)
            self.setting6a.setProperty("value", 0.1)
            self.setting7a.setProperty("value", 0.1)
            self.setting8a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting8a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting8a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting8a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting8a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

      def settingsSFCM(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)
            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(1)
            self.setting3a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(3)
            self.setting4a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setDecimals(1)
            self.setting5a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QSpinBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.setSingleStep(2)
            self.setting6a.setMinimum(1)
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.setting7 = QtGui.QLabel(self.groupBox_2)
            self.setting7.setObjectName(_fromUtf8("setting7"))
            self.gridLayout_3.addWidget(self.setting7, 7, 0, 1, 1)
            self.setting7a = QtGui.QComboBox(self.groupBox_2)
            self.setting7a.setObjectName(_fromUtf8("setting7a"))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting7a, 7, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("m")
            self.setting4.setText("Error Threshold")
            self.setting5.setText("Alfa")
            self.setting6.setText("Dim")
            self.setting7.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 2.0)
            self.setting4a.setProperty("value", 0.001)
            self.setting5a.setProperty("value", 1)
            self.setting6a.setProperty("value", 3)
            self.setting7a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting7a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting7a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting7a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting7a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

      def settingsSFCMI(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)
            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(1)
            self.setting3a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(3)
            self.setting4a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setDecimals(1)
            self.setting5a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QSpinBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.setSingleStep(2)
            self.setting6a.setMinimum(1)
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.setting7 = QtGui.QLabel(self.groupBox_2)
            self.setting7.setObjectName(_fromUtf8("setting7"))
            self.gridLayout_3.addWidget(self.setting7, 7, 0, 1, 1)
            self.setting7a = QtGui.QComboBox(self.groupBox_2)
            self.setting7a.setObjectName(_fromUtf8("setting7a"))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting7a, 7, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("m")
            self.setting4.setText("Error Threshold")
            self.setting5.setText("Alfa")
            self.setting6.setText("Dim")
            self.setting7.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 2.0)
            self.setting4a.setProperty("value", 0.001)
            self.setting5a.setProperty("value", 1)
            self.setting6a.setProperty("value", 3)
            self.setting7a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting7a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting7a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting7a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting7a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

      def settingsSFCMII(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)
            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(1)
            self.setting3a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(3)
            self.setting4a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setDecimals(1)
            self.setting5a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QSpinBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.setSingleStep(2)
            self.setting6a.setMinimum(1)
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.setting7 = QtGui.QLabel(self.groupBox_2)
            self.setting7.setObjectName(_fromUtf8("setting7"))
            self.gridLayout_3.addWidget(self.setting7, 7, 0, 1, 1)
            self.setting7a = QtGui.QComboBox(self.groupBox_2)
            self.setting7a.setObjectName(_fromUtf8("setting7a"))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.setting7a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting7a, 7, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("m")
            self.setting4.setText("Error Threshold")
            self.setting5.setText("Alfa")
            self.setting6.setText("Dim")
            self.setting7.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 2.0)
            self.setting4a.setProperty("value", 0.001)
            self.setting5a.setProperty("value", 1)
            self.setting6a.setProperty("value", 3)
            self.setting7a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting7a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting7a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting7a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting7a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

      def settingsKFCM(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)
            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(1)
            self.setting3a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(3)
            self.setting4a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setDecimals(1)
            self.setting5a.setSingleStep(10)
            self.setting5a.setMaximum(900)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QComboBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.addItem(_fromUtf8(""))
            self.setting6a.addItem(_fromUtf8(""))
            self.setting6a.addItem(_fromUtf8(""))
            #self.setting6a.addItem(_fromUtf8(""))
            #self.setting6a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("m")
            self.setting4.setText("Error Threshold")
            self.setting5.setText("Sigma")
            self.setting6.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 2.0)
            self.setting4a.setProperty("value", 0.001)
            self.setting5a.setProperty("value", 100)
            self.setting6a.setItemText(0, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting6a.setItemText(1, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting6a.setItemText(2, _translate("MainWindow", "SUM_MEMBERSHIP", None))

      def settingsSKFCM(self):
            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)
            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(1)
            self.setting3a.setSingleStep(0.5)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.setDecimals(3)
            self.setting4a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.setting5 = QtGui.QLabel(self.groupBox_2)
            self.setting5.setObjectName(_fromUtf8("setting5"))
            self.gridLayout_3.addWidget(self.setting5, 5, 0, 1, 1)
            self.setting5a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting5a.setObjectName(_fromUtf8("setting5a"))
            self.setting5a.setDecimals(1)
            self.setting5a.setSingleStep(10)
            self.setting5a.setMaximum(900)
            self.gridLayout_3.addWidget(self.setting5a, 5, 1, 1, 1)

            self.setting6 = QtGui.QLabel(self.groupBox_2)
            self.setting6.setObjectName(_fromUtf8("setting6"))
            self.gridLayout_3.addWidget(self.setting6, 6, 0, 1, 1)
            self.setting6a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting6a.setObjectName(_fromUtf8("setting6a"))
            self.setting6a.setDecimals(1)
            self.setting6a.setSingleStep(0.1)
            self.gridLayout_3.addWidget(self.setting6a, 6, 1, 1, 1)

            self.setting7 = QtGui.QLabel(self.groupBox_2)
            self.setting7.setObjectName(_fromUtf8("setting7"))
            self.gridLayout_3.addWidget(self.setting7, 7, 0, 1, 1)
            self.setting7a = QtGui.QSpinBox(self.groupBox_2)
            self.setting7a.setObjectName(_fromUtf8("setting7a"))
            self.setting7a.setSingleStep(2)
            self.setting7a.setMinimum(1)
            self.gridLayout_3.addWidget(self.setting7a, 7, 1, 1, 1)

            self.setting8 = QtGui.QLabel(self.groupBox_2)
            self.setting8.setObjectName(_fromUtf8("setting8"))
            self.gridLayout_3.addWidget(self.setting8, 8, 0, 1, 1)
            self.setting8a = QtGui.QComboBox(self.groupBox_2)
            self.setting8a.setObjectName(_fromUtf8("setting8a"))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.setting8a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting8a, 8, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("m")
            self.setting4.setText("Error Threshold")
            self.setting5.setText("Sigma")
            self.setting6.setText("Alfa")
            self.setting7.setText("Dim")
            self.setting8.setText("Error Type")
            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 2.0)
            self.setting4a.setProperty("value", 0.001)
            self.setting5a.setProperty("value", 100)
            self.setting6a.setProperty("value", 1)
            self.setting7a.setProperty("value", 3)
            self.setting8a.setItemText(0, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting8a.setItemText(1, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting8a.setItemText(2, _translate("MainWindow", "SUM_MEMBERSHIP", None))

      def selectImage(self):
            self.canvas.figure.clear()
            fileName = QtGui.QFileDialog.getOpenFileName(self, "Open Image File", QtCore.QDir.homePath(), "Image Files (*)")

            if fileName:
                  self.filename=fileName.toLocal8Bit().data()
                  self.img = np.array(Image.open(self.filename))
                  plt.figure(self.figure.number)
                  self.m= plt.imshow(self.img)
                  plt.axis("off")
                  self.m.figure.canvas.draw()

            self.f = os.path.basename(self.filename)

            return self.filename, self.img, self.f

      def selectAlgorithm(self):
            if (self.filename==None):
                  QtGui.QMessageBox.critical(self, "Error", "Select an image!", QtGui.QMessageBox.Ok)

            else:
                  # Caricamento immagine originale
                  self.im, features = ImageUtils.loadImage(self.filename)

                  if(self.KMRadioButton.isChecked()):
                        if (self.setting4a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting4a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting4a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting4a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting4a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        kmeans = KMeans(self.im, c = self.setting1a.value(), maxIterations = self.setting2a.value(),
                                        e = self.setting3a.value(), errorType=self.err_type)

                        self.clusteringResult = kmeans

                        kmeans.execute() # Esegui K-means
                        self.res = kmeans.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = kmeans.calculateSSE()
                        self.xie = kmeans.calculateXieBeniIndex
                        self.entropy_memb = kmeans.calculateInternalEntropy()

                  if(self.FCMradioButton.isChecked()):
                        if (self.setting5a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting5a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting5a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting5a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting5a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        fcm = FCM(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                     m=self.setting4a.value(), e=self.setting3a.value(), errorType=self.err_type)

                        self.clusteringResult = fcm

                        fcm.execute() # Esegui FCM

                        self.res = fcm.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = fcm.calculateSSE()
                        self.xie = fcm.calculateXieBeniIndex
                        self.entropy_memb = fcm.calculateInternalEntropy()

                  if(self.FCMSradioButton.isChecked()):
                        if (self.setting8a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting8a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting8a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting8a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting8a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        fcms = FCMS(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                    m=self.setting4a.value(), p=self.setting6a.value(),
                                    q=self.setting7a.value(), e=self.setting3a.value(),
                                    dim=self.setting5a.value(), errorType=self.err_type)
                        self.clusteringResult = fcms
                        fcms.execute() # Esegui FCMS
                        self.res = fcms.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = fcms.calculateSSE()
                        self.xie = fcms.calculateXieBeniIndex
                        self.entropy_memb = fcms.calculateInternalEntropy()

                  if(self.SFCMradioButton.isChecked()):
                        if (self.setting7a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting7a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting7a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting7a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting7a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        sfcm = SFCM(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                    m=self.setting3a.value(), e=self.setting4a.value(),
                                    alfa=self.setting5a.value(), dim=self.setting6a.value(),
                                    errorType=self.err_type)
                        self.clusteringResult = sfcm
                        sfcm.execute() # Esegui SFCM
                        self.res = sfcm.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = sfcm.calculateSSE()
                        self.xie = sfcm.calculateXieBeniIndex
                        self.entropy_memb = sfcm.calculateInternalEntropy()

                  if(self.SFCMIradioButton.isChecked()):
                        if (self.setting7a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting7a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting7a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting7a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting7a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        sfcm1 = SFCM_1(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                    m=self.setting3a.value(), e=self.setting4a.value(),
                                    alfa=self.setting5a.value(), dim=self.setting6a.value(),
                                    errorType=self.err_type)
                        self.clusteringResult = sfcm1
                        sfcm1.execute() # Esegui SFCM I

                        self.res = sfcm1.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = sfcm1.calculateSSE()
                        self.xie = sfcm1.calculateXieBeniIndex
                        self.entropy_memb = sfcm1.calculateInternalEntropy()

                  if(self.SFCMIIradioButton.isChecked()):
                        if (self.setting7a.currentText()=="OBJFN"):
                              self.err_type = 0
                        if (self.setting7a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting7a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting7a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        if (self.setting7a.currentText()=="MAX_MEMBERSHIP"):
                              self.err_type = 4

                        sfcm2 = SFCM_2(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                    m=self.setting3a.value(), e=self.setting4a.value(),
                                    alfa=self.setting5a.value(), dim=self.setting6a.value(),
                                    errorType=self.err_type)
                        self.clusteringResult = sfcm2
                        sfcm2.execute() # Esegui SFCM II
                        self.res = sfcm2.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = sfcm2.calculateSSE()
                        self.xie = sfcm2.calculateXieBeniIndex
                        self.entropy_memb = sfcm2.calculateInternalEntropy()

                  if(self.KFCMradioButton.isChecked()):
                        #if (self.setting6a.currentText()=="OBJFN"):
                              #self.err_type = 0
                        if (self.setting6a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting6a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting6a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3
                        #if (self.setting6a.currentText()=="MAX_MEMBERSHIP"):
                              #self.err_type = 4

                        kfcm = KFCM(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                    m=self.setting3a.value(), sigma=self.setting5a.value(),
                                    e=self.setting4a.value(), errorType=self.err_type)
                        self.clusteringResult = kfcm
                        kfcm.execute() # Esegui KFCM
                        self.res = kfcm.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = kfcm.calculateSSE()
                        self.xie = kfcm.calculateXieBeniIndex
                        self.entropy_memb = kfcm.calculateInternalEntropy()

                  if(self.SKFCMradioButton.isChecked()):
                        if (self.setting8a.currentText()=="MAX_CENTROIDS"):
                              self.err_type = 1
                        if (self.setting8a.currentText()=="SUM_CENTROIDS"):
                              self.err_type = 2
                        if (self.setting8a.currentText()=="SUM_MEMBERSHIP"):
                              self.err_type = 3

                        skfcm = SKFCM(self.im, c=self.setting1a.value(), maxIterations=self.setting2a.value(),
                                      m=self.setting3a.value(), sigma=self.setting5a.value(), e=self.setting4a.value(),
                                      alfa=self.setting6a.value(), dim=self.setting7a.value(),
                                      errorType=self.err_type)
                        self.clusteringResult = skfcm
                        skfcm.execute() # Esegui SKFCM
                        self.res = skfcm.getLabelledMatrix()

                        self.codeim = np.array(self.res)

                        folder = "../Progetto Tesi/output/"
                        ImageUtils.saveImage(self.codeim, folder)

                        self.sse = skfcm.calculateSSE()
                        self.xie = skfcm.calculateXieBeniIndex
                        self.entropy_memb = skfcm.calculateInternalEntropy()

      def openResult(self):
            self.var = Result()
            self.var.setMetrics(sse=self.sse, xie=self.xie, entropy_memb=self.entropy_memb)
            self.var.setMetrics1(k=self.setting1a.value(), res=self.res, clusteringResult=self.clusteringResult)
            self.var.showImage(self.codeim, self.im, self.f)
            self.var.numCluster(k=self.setting1a.value())
            self.var.show()

      def main(self):
            self.show()

      def progress(self, completed):
            self.progressBar.setValue(completed)
            print (completed)

      def resetValue(self):
            self.canvas.figure.clear()

            self.KMRadioButton.setChecked(True)

            self.groupBox_2.deleteLater()
            self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
            self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
            self.groupBox_2.setTitle(_translate("MainWindow", "Settings", None))
            self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
            self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))

            self.setting1 = QtGui.QLabel(self.groupBox_2)
            self.setting1.setObjectName(_fromUtf8("setting1"))
            self.gridLayout_3.addWidget(self.setting1, 0, 0, 1, 1)
            self.setting1a = QtGui.QSpinBox(self.groupBox_2)
            self.setting1a.setMinimum(2)
            self.setting1a.setObjectName(_fromUtf8("setting1a"))
            self.gridLayout_3.addWidget(self.setting1a, 0, 1, 1, 1)

            self.setting2 = QtGui.QLabel(self.groupBox_2)
            self.setting2.setObjectName(_fromUtf8("setting2"))
            self.gridLayout_3.addWidget(self.setting2, 1, 0, 1, 1)
            self.setting2a = QtGui.QSpinBox(self.groupBox_2)
            self.setting2a.setMinimum(2)
            self.setting2a.setObjectName(_fromUtf8("setting2a"))
            self.gridLayout_3.addWidget(self.setting2a, 1, 1, 1, 1)

            self.setting3 = QtGui.QLabel(self.groupBox_2)
            self.setting3.setScaledContents(True)
            self.setting3.setObjectName(_fromUtf8("setting3"))
            self.gridLayout_3.addWidget(self.setting3, 3, 0, 1, 1)
            self.setting3a = QtGui.QDoubleSpinBox(self.groupBox_2)
            self.setting3a.setObjectName(_fromUtf8("setting3a"))
            self.setting3a.setDecimals(3)
            self.setting3a.setSingleStep(0.001)
            self.gridLayout_3.addWidget(self.setting3a, 3, 1, 1, 1)

            self.setting4 = QtGui.QLabel(self.groupBox_2)
            self.setting4.setObjectName(_fromUtf8("setting4"))
            self.gridLayout_3.addWidget(self.setting4, 4, 0, 1, 1)
            self.setting4a = QtGui.QComboBox(self.groupBox_2)
            self.setting4a.setObjectName(_fromUtf8("setting4a"))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.setting4a.addItem(_fromUtf8(""))
            self.gridLayout_3.addWidget(self.setting4a, 4, 1, 1, 1)

            self.gridLayout.addWidget(self.groupBox_2, 5, 0, 6, 3)

            self.setting1.setText("Cluster Number")
            self.setting2.setText("Max Iteration")
            self.setting3.setText("Error Threshold")
            self.setting4.setText("Error Type")

            self.setting1a.setProperty("value", 2)
            self.setting2a.setProperty("value", 2)
            self.setting3a.setProperty("value", 0.001)
            self.setting4a.setItemText(0, _translate("MainWindow", "OBJFN", None))
            self.setting4a.setItemText(1, _translate("MainWindow", "MAX_CENTROIDS", None))
            self.setting4a.setItemText(2, _translate("MainWindow", "SUM_CENTROIDS", None))
            self.setting4a.setItemText(3, _translate("MainWindow", "SUM_MEMBERSHIP", None))
            self.setting4a.setItemText(4, _translate("MainWindow", "MAX_MEMBERSHIP", None))

            plt.figure(self.figure.number)
            plt.text(0.4,0.5,'<image>',fontsize=22,fontstyle='italic', color="Grey")
            plt.axis('off')
            self.canvas.draw()

            self.filename=None

            return self.filename

      def closeEvent(self, event):
            reply = QtGui.QMessageBox.question(self, 'Message',
                  "Are you sure to quit?", QtGui.QMessageBox.Yes |
                  QtGui.QMessageBox.No, QtGui.QMessageBox.No)

            if reply == QtGui.QMessageBox.Yes:
                  shutil.rmtree("../Progetto Tesi/output")
                  event.accept()
            else:
                  event.ignore()

if __name__=='__main__':
      app = QtGui.QApplication(sys.argv)
      form = MainWindow()
      form.main()
      app.exec_()