# -*- coding: utf-8 -*-
from abc import abstractmethod, ABCMeta
from numpy import *
import numpy as np
import copy
import math as mt
import time
from PyQt5 import QtCore,QtGui
from Progress import *

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Clustering(object):
    ERROR_OBJFN = 0
    """Costante utilizzata per indicare il tipo di errore. Utilizzando tale valore l'errore viene calcolato come differenza
        delle funzoni obietivo"""

    ERROR_MAX_CENTROIDS = 1
    """Costante utilizzata per indicare il tipo di errore. Utilizzando tale valore l'errore viene calcolato come il
        valore massimo della differenza tra i centroidi in valore assoluto """

    ERROR_SUM_CENTROIDS = 2
    """Costante utilizzata per indicare il tipo di errore. Utilizzando tale valore l'errore viene calcolato come la somma
       della differenza tra i centroidi al quadrato"""

    ERROR_SUM_MEMBERSHIP = 3
    """Costante utilizzata per indicare il tipo di errore. Utilizzando tale valore l'errore viene calcolato come la
        somma dei valori della differanza tra le due matrici di memembership"""

    ERROR_MAX_MEMBERSHIP = 4
    """Costante utilizzata per indicare il tipo di errore. Utilizzando tale valore l'errore viene calcolato come il valore
        massimo della differanza tra le due matrici di memembership"""

    """Classe astratta. Implementa metodi comuni a tutti gli algoritmi di clustering"""
    __metaclass__ = ABCMeta # Classe astratta


    @abstractmethod
    def calculateClusterCenters(self):
        """ Astratto. Calcola i centroidi di ogni cluster."""

        pass

    @abstractmethod
    def calculateMembership(self):
        """ Astratto. Calcola la matrice di membership a partire dai centroidi"""

        pass

    @abstractmethod
    def calculateObjectiveFunction(self):
        """ Astratto. Calcola la funzione obiettivo dell'algoritmo"""

        pass

    def __init__(self, img, c, maxIterations, e, errorType):
        """ Costruttore. Imposta i parametri dell'algoritmo di clustering.

            :param img: list
                la matrice rappresentante l'immagine da clusterizzare
            :param c: int
                il numero di cluster da trovare
            :param maxIterations: int
                il numero massimo di iterazioni dell'algoritmo
            :param e: float
                l'errore minimo. Una delle condizioni di stop dell'algoritmo.
            :param errorType: int
                il tipo di errore

            :returns: mu: np.array
                una matrice di membership di dimensioni Width x Height x Cluster
        """

        self.img = img
        self.c = c
        self.maxIterations = maxIterations
        self.e = e
        self.errorType = errorType

        self.width = img.shape[0]
        self.height = img.shape[1]
        self.nChannels = img.shape[2]

        #print("\nNumero canali: " + str(self.nChannels))

        self.membership = None # Matrice di membership
        self.centroids = [[0.0 for i in range(self.nChannels)] for j in range(self.c)]

    def openProgress(self):
        self.j = Progress()
        self.j.show()

    def execute(self):
        """ Esegue l'algoritmo di clustering """

        # Genera matrice mu
        self.membership = self.genRndMu()

        # Genera casualmente i centroidi
        self.genRndCentroids()
        #print("Centroids: " + str(self.centroids))
        lastCentroids = copy.deepcopy(self.centroids)
        lastMembership = None
        lastJ = 0

        self.prog = 100/self.maxIterations
        self.compl = 0
        self.openProgress()

        for i in range(self.maxIterations):
            # Calcola matrice di membership
            now = time.clock()
            self.calculateMembership()
            s = str(i+1)
            t = str(time.clock()-now)

            self.compl = self.prog + self.compl
            time.sleep(time.clock()-now)
            self.j.progress(self.compl)
            sys.stdout.flush()

            print("Step " + s + " - Tempo impiegato: " + t)

            # Calcola funzione obiettivo con matrice membership casuale
            currentJ = self.calculateObjectiveFunction()

            # Calcola centroidi
            self.calculateClusterCenters()
            #print("Centroids: " + str(self.centroids))

            # Controllo per stop prematuro
            if (self.errorType == self.ERROR_OBJFN):
                if (self.calculateError(lastJ, currentJ) < self.e):
                    self.j.quit()
                    break
            elif (self.errorType == self.ERROR_MAX_CENTROIDS or self.errorType == self.ERROR_SUM_CENTROIDS):
                if (self.calculateError(lastCentroids, self.centroids) < self.e):
                    self.j.quit()
                    break
            elif (self.errorType == self.ERROR_SUM_MEMBERSHIP):
                if (lastMembership != None):
                    if (self.calculateError(lastMembership, self.membership) < self.e):
                        self.j.quit()
                        break

            lastJ = currentJ
            lastCentroids = copy.deepcopy(self.centroids)
            lastMembership = copy.deepcopy(self.membership)

        self.j.quit()

    def genRndMu(self):
        """ Genera una matrice di memebership casuale di dimensione width x height x c.

            :returns: mu: np.array
                una matrice di membership di dimensione width x height x c.
        """

        random.seed(65536)

        # Genera matrice di membership casuale width x height x c
        mu = random.random((self.width, self.height, self.c))

        # Normalizzazione
        for i in range(self.width):

            for j in range(self.height):
                # Calcola somma della riga
                sumRow = 0.0

                for k in range(self.c):
                    sumRow += mu[i][j][k]

                # Dividi la somma della riga per ogni elemento cosi' il totale e' 1
                for k in range(self.c):
                    mu[i][j][k] /= sumRow

        #set_printoptions(threshold=nan)

        return array(mu)


    def genRndCentroids(self):
        """ Inizializza i centroidi di iniziali casualmente.
        """
        max3 = 0
        min3 = 0
        for i in range(self.width):
            for j in range(self.height):
                max2= max(self.img[i][j])
                min2 = min(self.img[i][j])

                if (max2 > max3):
                    max3 = max2
                if (min2 < min3):
                    min3 = min2

        for i in range(self.c):
            for j in range(self.nChannels):
                self.centroids[i][j] = random.uniform(min3, max3)


    def getLabelledMatrix(self):
        """ Assegna ad ogni pixel nell'immagine il numero del cluster con la maggior probabilita' di appartenenza.

            :returns: res: list
                una matrice Width x Height dove ogni pixel e' sostituito con il numero del corrispettivo cluster.
        """

        # Creazione matrice di cluster Width x Height
        res = [[0.0 for i in range(self.height)] for j in range(self.width)]

        for w in range(self.width):
            for h in range(self.height):
                # Per ogni riga prende l'indice (cluster) con prob. piu' alta
                idMax = 0

                # Trova prob. massima
                for k in range(self.c):
                    if (self.membership[w][h][k] > self.membership[w][h][idMax]):
                        idMax = k

                res[w][h] = idMax # Memorizza indice

        # Restituisce la matrice etichettata con il cluster di prob. massima
        # per ogni data point
        return res


    def calcDistance(self, x, y):
        """ Calcola la distanza Euclidea tra due datapoint.

            :param x: list
                il primo datapoint
            :param y: list
                il secondo datapoint

            :returns: float
               la distanza euclidea
        """

        distance = (x - y)
        distance *= distance

        return sqrt(distance[0])


    def calcSquaredDistance(self, x, y):
        """ Calcola la distanza Euclidea tra due datapoint, elevandola al quadrato.


            :param x: list
                il primo datapoint
            :param y: list
                il secondo datapoint


            :returns: float
               la distanza euclidea
        """

        distance = (x - y)
        distance *= distance

        return distance[0]


    def sort(self, list):
        """ Ordina una lista di datapoint utilizzando la funzione __compareTo.


            :param list: list
                la lista da ordinare


            :returns: list
               la lista ordinata
        """
        return sorted(list, cmp = self.__compareTo)


    def __compareTo(self, a, b):
        """ Stabilisce una relazione d'ordine tra due datapoint.

           :param a: list
                il primo datapoint
           :param b: list
                il secondo datapoint


            :returns: int
               0 se a = b
               1 se a > b
               -1 se a < b
        """
        # Calcola differenza tra triple
        diff = array(a) - array(b)

        # Calcola somma delle differenze
        totalDiff = 0.0

        for i in range(len(diff)):
            totalDiff += diff[i]

        # Restituisci -1 se a < b, 1 se a > 1, 0 se a == b
        if (totalDiff < 0):
            return -1
        elif (totalDiff > 0):
            return 1

        return 0


    def findWindow(self, w, h, dim):
        """Trova le coordinate della finestra.

            :param w: int
                Coordinata x del pixel in cui e' centrata la finestra
            :param h: int
                Coordinata y del pixel in cui e' centrata la finestra
            :param dim: int
                dimensione finestra. Deve essere pari.

            :returns: windowCoordinates: list
                coordinate della finestra
        """

        if (dim % 2 == 0):
            print ("Errore! La dimensione finestra deve essere dispari!")
            pass

        inizioW = w - int(dim / 2)
        fineW = w + int(dim / 2)
        if (inizioW < 0):
            inizioW = 0
        if (fineW >= len(self.img)):
            fineW = len(self.img) - 1

        inizioH = h - int(dim / 2)
        fineH = h + int(dim / 2)
        if (inizioH < 0):
            inizioH = 0
        if (fineH >= len(self.img[0])):
            fineH = len(self.img[0]) - 1

        windowCoordinates = []
        for i in range(inizioW, fineW + 1):
            for j in range(inizioH, fineH + 1):
                if (i != w or j != h):
                    windowCoordinates.append([i, j])

        return windowCoordinates


    def calculateError(self, last, current):
        """
        Calcola l'errore.

           :param:last: float
                se il tipo di errore è ERROR_OBJFN allora last è la funzione obiettivo nella precedente iterazione
                se il tipo di errore è ERROR_MAX_CENTROIDS o ERROR_SUM_CENTROIDS allora last sono i centroidi della precedente iterazione
                se il tipo di errore è ERROR_MAX_MEMBERSHIP o ERROR_SUM_MEMBERSHIP allora last sono le membership della precedente iterazione
           :param:current: float
                se il tipo di errore è ERROR_OBJFN allora current è la funzione obiettivo nell'iterazione corrente
                se il tipo di errore è ERROR_MAX_CENTROIDS o ERROR_SUM_CENTROIDS allora current sono i centroidi nell'iterazione corrente
                se il tipo di errore è ERROR_MAX_MEMBERSHIP o ERROR_SUM_MEMBERSHIP allora current sono le membership nell'iterazione corrente

           :returns: float
                l'errore
        """

        if (self.errorType == self.ERROR_OBJFN):
            # Differenza tra funzioni obiettivo
            err = abs(last - current)
            #print("Errore: " + str(err))
            return err

        elif (self.errorType == self.ERROR_MAX_CENTROIDS):
            # Differenza tra centroidi in valore assoluto
            diff = [ 0.0 for i in range(len(last)) ]

            for i in range(len(current)):
                sum1 = 0.0
                sum2 = 0.0
                for j in range(len(current[i])):
                    sum1 += pow(current[i][j], 2.0)
                    sum2 += pow(last[i][j], 2.0)

                #print("Pow: " + str(sum1) + " " + str(sum2))
                diff[i] = abs(sqrt(sum1) - sqrt(sum2))

            #print("Errore: " + str(np.max(diff)))

            return np.max(diff)

        elif (self.errorType == self.ERROR_SUM_CENTROIDS):
            # Somma delle distanze euclidee tra centroidi
            tot = 0.0

            for i in range(len(current)):
                diff = 0.0
                # Differenza tra triplette al quadrato
                for j in range(len(current[i])):
                    diff += pow((last[i][j] - current[i][j]), 2.0)

                diff = sqrt(diff)
                # Somma delle differenze al quadrato
                tot += diff

            #print("Errore: " + str(tot))
            return tot

        elif (self.errorType == self.ERROR_SUM_MEMBERSHIP):
            diff = pow((last - current), 2.0)
            tot = sqrt(sum(diff))
            #print("Errore: " + str(tot))

            return tot

        elif (self.errorType == self.ERROR_MAX_MEMBERSHIP):
            diff = abs(last - current) # Differenza tra matrici di membership

            # Trova il massimo della matrice di differenza tra membership
            max = 0
            for w in range(self.width):
                for h in range(self.height):
                    for k in range(self.c):

                        if (diff[w][h][k] > max):
                            max = diff[w][h][k]

            #print("Errore: " + str(max))
            return max

    def calculateSSE(self):
        """Calcola la metrica SSE(Sum of Squares Error).

            :return: sse:float
                il valore dell'SSE.
        """

        sse = 0.0
        for k in range(self.c):
            for w in range(self.width):
                for h in range(self.height):
                    sse += pow(self.calcDistance(self.img[w][h], self.centroids[k]), 2.0)

        return sse

    @property
    def calculateXieBeniIndex(self):
        """Calcola l'indice di Xie-Beni.

            :return: indexXB: float
                il valore dell'indice di XieBeni.
        """

        top = 0.0
        for k in range(self.c):
            for w in range(self.width):
                for h in range(self.height):
                    distance = pow(self.calcDistance(self.img[w][h], self.centroids[k]), 4.0)
                    top += pow(self.membership[w][h][k], 2.0) * distance

        min = 0.0
        for i in range(self.c - 1):
            for j in range(i + 1, self.c):
                distance = pow(self.calcDistance(np.array(self.centroids[i]), np.array(self.centroids[j])), 4.0)

                if (min == 0 or distance < min):
                    min = distance

        n = self.width * self.height
        bottom = n * min

        return top / float(bottom)

    def calculateInternalEntropy(self):
        """Calcola l'entropia delle membership.

        :return: entropy: float
            il valore dell'entropia delle membership
        """

        entropy = 0.0
        for k in range(self.c):
            for w in range(self.width):
                for h in range(self.height):
                    if (self.membership[w][h][k] > 0):
                        entropy += self.membership[w][h][k] * mt.log(self.membership[w][h][k], 2)

        return (-1 * entropy)