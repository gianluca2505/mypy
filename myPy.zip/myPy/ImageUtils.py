# -*- coding: utf-8 -*-
import matplotlib.pyplot as pl
import numpy as np
import matplotlib.cm as cm
from scipy.misc import *
from PIL import Image
from Metrics import Metrics
import matplotlib.image as mpimg


class ImageUtils:

    @staticmethod
    def showImage(codeim, im, title):
        """Mostra l'immagine segmentata.

            :param codeim: np.array
                la matrice che rappresenta l'immagine segmentata
            :param im: np.array
                la matrice dell'immagine da segmentare
            :param title: string
                il titolo dell'immagine da visualizzare

            :returns: code: np.array
                la matrice ridimensionata
        """

        code = imresize(codeim, im.shape[:2], interp = 'nearest') # Ridimensiona l'immagine

        #fig= pl.figure(num = title)
        pl.imshow(code, cmap=cm.Greys_r)

        pl.imshow(code)
        #cv2.imshow('Clustering K-means', code)
        pl.show()

        return code

    @staticmethod
    def getMetrics(segmentedImage, corrSegmentedImage, k, nClasses, clusteringResult):
        """Metodo statico che restituisce le metriche calcolate per valutare la segmentazione.

            :param: segmentedImage: np.array
                l'immagine segmentata
            :param: corrSegmentedImage: np.array
                l'immagine correttamente segmentata
            :param: k: int
                il numero di cluster individuati
            :param: nClasses: int
                il numero di classi nell'immagine correttamente segmentata
            :param: clusteringResult: Clustering
                oggetto contenente i risultati dell'algoritmo eseguito

            :return: (tableList, accuracy): (PrettyTabele, float)
                una coppia constituita da un tabella contenente tutte le metriche calcolate e il valore dell'accuratezza.
            """

        tableList = []

        acc = Metrics(segmentedImage, corrSegmentedImage, k, nClasses, clusteringResult.membership)

        # Mostra accuratezza per classe (Indice di Jaccard)
        accuracyClasses = acc.calculateJaccardIndex()
        entropyList = acc.calculateEntropy()
        purityList = acc.calculatePurity()
        precisionList = acc.calculatePrecision()
        recallList = acc.calculateRecall()
        fscoreList = acc.calculateFScore()
        areas = acc.calculateClusterArea()

        from prettytable import PrettyTable

        # Header
        header = []
        header.append("Cluster/Class")
        for i in range(nClasses ):
            header.append(str(i))
        header.append("Entropia")
        header.append("Purezza")
        header.append("Indice di Jaccard")
        header.append("Precision")
        header.append("Recall")
        header.append("F-score")
        header.append("Area stimata")
        tableList.append(header) # Aggiungi header a tabella

        table = PrettyTable(header) # Definizione oggetto tabella

        precision = 4 # Precisione decimali

        # Riempimento tabella
        for j in range(k):
            row = []
            row.append(str(j))
            for i in range(nClasses):
                row.append(acc.getClassesClusters()[j].qtMatchWithAllClasses[i]) # Inserisci intersezione classe-cluster

            row.append(round(entropyList[j], precision))
            row.append(round(purityList[j], precision))
            row.append(round(accuracyClasses[j], precision))
            row.append(round(precisionList[j], precision))
            row.append(round(recallList[j], precision))
            row.append(round(fscoreList[j], precision))
            row.append(round(areas[j], precision))

            table.add_row(row) # Inserisci riga in tabella
            tableList.append(row)

        tableList.append("")
        tableList.append("Accuracy: " + str(acc.calculateAccuracy())) # Mostra accuratezza
        tableList.append("Entropia totale: " + str(round(acc.calculateTotalEntropy(), precision)))
        tableList.append("Purezza totale: " + str(round(acc.calculateTotalPurity(), precision)))
        tableList.append("SSE: " + str(round(clusteringResult.calculateSSE(), precision)))
        tableList.append("Xie Beni: " + str(round(clusteringResult.calculateXieBeniIndex, precision)))
        tableList.append("Entropia membership: " + str(round(clusteringResult.calculateInternalEntropy(), precision)))

        print ("Accuracy: " + str(acc.calculateAccuracy())) # Stampa accuratezza

        return (tableList, acc.calculateAccuracy())

    @staticmethod
    def loadResizeImage(path, steps):
        """Carica l'immagine e la ridimensiona in base agli step definiti.

            :param path: string
                il percorso dell'immagine.
            :param steps: int
                il numero di blocchi per larghezza ed altezza in cui suddividere l'immagine.
            :returns: im: np.array
                la matrice dell'immagine caricata
            :returns: features: np.array
                una lista dei pixel dell'immagine ridimensionata
        """
        im = np.array(Image.open(path))

        pl.figure(num = "Immagine originale")
        pl.imshow(im)

        # Divisione immagine in regioni di dimensione steps*steps
        dx = im.shape[0] / float(steps)  # Larghezza di ciascuna regione
        dy = im.shape[1] / float(steps)  # Altezza di ciascuna regione

        # Calcola la media del colore per ciascuna regione
        features = []
        for x in range(steps):
            for y in range(steps):
                # Calcola media per ciascun canale
                R = np.mean(im[x * dx : (x + 1) * dx, y * dy : (y + 1) * dy, 0])
                G = np.mean(im[x * dx : (x + 1) * dx, y * dy : (y + 1) * dy, 1])
                B = np.mean(im[x * dx : (x + 1) * dx, y * dy : (y + 1) * dy, 2])

                features.append([R, G, B])

        features = np.array(features, 'f')  # Trasforma in array

        return im, features

    @staticmethod
    def loadImage(path):
        """Carica l'immagine, la mostra e la destruttura.

            :param path: string
                il percorso dell'immagine.

            :returns: im: np.array
                la matrice dell'immagine caricata
            :returns: features: np.array
                una lista dei pixel dell'immagine
        """

        im = np.array(Image.open(path))

        #pl.figure(num = "Immagine originale")
        #pl.imshow(im)

        # Verifica se e' presente un solo canale (tuple con uguali valori)
        oneChannel = True
        # Verifica se sono immagini con più di 3 canali. Se si, riducili a 3.
        actualChannels = len(im[0][0])
        #print ("Canali effettivi: " + str(actualChannels))
        if (actualChannels > 3):
            actualChannels = 3

        for i in range(len(im)):
            for j in range(len(im[i])):

                for k in range(actualChannels - 1):
                    if (im[i][j][k] != im[i][j][k +1]):
                        oneChannel = False
                        break

        #print("Singolo canale: " + str(oneChannel))

        #print("IM multi-canale: " + str(im))

        # Inserisci le tuple dei pixel sequenzialmente in un array
        features = []
        if (not oneChannel):
            # Caso multi-canale: Aggiungi tuple per ciascun pixel

            for i in range(len(im)):
                for j in range(len(im[i])):
                    features.append(im[i][j])
        else:
            # Caso 1 canale: Aggiungi singoli valori per ciascun pixel
            im2 = [[[0.0 for k in range(1)] for h in range(len(im[0]))] for w in range(len(im))]

            for i in range(len(im)):
                for j in range(len(im[i])):
                    features.append(im[i][j][0])
                    im2[i][j][0] = im[i][j][0] # Converti matrice im ad un solo canale

            im = np.array(im2)
        #print("IM con 1 canale: " + str(im))
        features = np.array(features, 'f')  # Trasforma in array

        return im, features

    @staticmethod
    def getClass(elem, tuple):
        """ Verifica se la tripletta e' presente tra quelle a cui e' stata assegnata una classe
            :param elem: list
                la tripletta
            :param tuple:list
                lista delle classi
        """
        for i in range(len(tuple)):
            exists = True
            for k in range(len(elem)):
                if (elem[k] != tuple[i][k]):
                    exists = False

            if (exists == True):
                return i

        return None

    @staticmethod
    def convertImageMatrixToLabelledMatrix(matrix):
        """Restituisce una matrice contrassegnata dalle classi associate alle varie triplette

            :param: matrix: np.array
                la matrice dell'immagine

            :return: (newMatrix, len(tuple))
                 una coppia matrice etichettata, numero di classi
        """
        tuple = []

        newMatrix = [[0 for i in range(len(matrix[0]))] for j in range(len(matrix))]

        for i in range(len(matrix)):
            for j in range(len(matrix[i])):
                # Verifica se alla tripletta e' stata assegnata gia' una classe
                classNumber = ImageUtils.getClass(matrix[i][j], tuple)
                if (classNumber != None):
                    newMatrix[i][j] = classNumber # Assegna classe gia' esistente
                else:
                    newMatrix[i][j] = len(tuple) # Assegna classe
                    tuple.append(matrix[i][j]) # Aggiunge tripletta RGB

        return newMatrix, len(tuple)

    @staticmethod
    def saveImage(img, path):
        """Salva l'immagine

            :param: img: np.array
                immagine da salvare
            :param: path: string
                percorso in cui salvare l'immagine
        """

        mpimg.imsave(path + "temp.png", np.array(img))
