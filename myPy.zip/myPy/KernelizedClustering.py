from abc import ABCMeta
from numpy import *
import copy
from Clustering import Clustering
import time
from Progress import *

class KernelizedClustering(Clustering):
    """Classe astratta. Contiene metodi comuni agli algoritmi Kernelized"""
    __metaclass__ = ABCMeta # Classe astratta

    def __init__(self, img, c, maxIterations, m, sigma, e, errorType):
        """Costruttore. Chiama costruttore superclasse"""

        self.sigma = sigma # Ampiezza del kernel Gaussiano
        self.m = m

        Clustering.__init__(self, img, c, maxIterations, e, errorType)

    def openProgress(self):
        self.j = Progress()
        self.j.show()

    def execute(self):
        """Override. Esegue algoritmo SKFCM"""

        # Genera matrice mu
        self.membership = self.genRndMu()
        # Genera centroidi casuali
        lastCentroids = self.genRndCentroids()

        # Memorizza membership iniziale (casuale)
        lastMembership = copy.deepcopy(self.membership)

        self.prog = 100/self.maxIterations
        self.compl = 0
        self.openProgress()

        for i in range(self.maxIterations):
            # Calcola centroidi
            now = time.clock()

            self.calculateClusterCenters()
            #print("Centroidi: " + str(self.centroids))

            self.compl = self.prog + self.compl
            time.sleep(time.clock()-now)
            self.j.progress(self.compl)
            sys.stdout.flush()

            # Calcola matrice dei membership
            self.calculateMembership()

             # Controllo per stop prematuro
            if (self.errorType == self.ERROR_MAX_CENTROIDS or self.errorType == self.ERROR_SUM_CENTROIDS):
                if (lastCentroids != None):
                    if (self.calculateError(lastCentroids, self.centroids) < self.e):
                        self.j.quit()
                        break
            elif (self.errorType == self.ERROR_SUM_MEMBERSHIP):
                if (self.calculateError(lastMembership, self.membership) < self.e):
                    self.j.quit()
                    break

            lastCentroids = copy.deepcopy(self.centroids)
            lastMembership = copy.deepcopy(self.membership)

        self.j.quit()

    def kernel(self, x, y):
        """Calcola il kernel Gaussiano.

            :param v1: list
                primo datapoint
            :param v2: list
                secondo datapoint
            :param sigma: float
                parametro sigma del kernel Gaussiano.

            :returns: float
                il risultato della funzione kernel applicata a v1 e v2
        """
        return exp(-1* pow(self.calcDistance(x, y), 2.0) / pow(self.sigma, 2.0))


    def calculateClusterCenters(self):
        """ Override. Calcola i centroidi a partire dall'attuale membership tramite il trucco del kernel."""

        for k in range(self.c):
            top = 0.0
            bottom = 0.0

            for h in range(self.height):
                for w in range(self.width):
                    aPixel = self.img[w][h]
                    kernel = self.kernel(aPixel, self.centroids[k])
                    membm = pow(self.membership[w][h][k], self.m)

                    top += membm * aPixel * kernel # Numeratore

                    bottom += membm * kernel# Denominatore

            self.centroids[k] = top / bottom


    def calculateObjectiveFunction(self):
        """Funzione non implementata"""
        pass
