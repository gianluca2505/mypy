# -*- coding: utf-8 -*-

from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt
from PyQt5 import QtCore, QtGui
from ImageUtils import *

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Window(object):
    def setupUi(self, MainWindow):
        self.setWindowIcon(QtGui.QIcon('icone/python_logo.png'))
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(1650, 830)
        MainWindow.setMinimumSize(QtCore.QSize(1061, 728))
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.gridLayout = QtGui.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))

        #toolbar
        saveAction = QtGui.QAction(QtGui.QIcon('icone/save'), 'Save', self)
        saveAction.setIconText("Save")
        saveAction.setShortcut('Ctrl+S')
        saveAction.triggered.connect(self.save)
        zoomAction = QtGui.QAction(QtGui.QIcon('icone/zoom_in'), 'Zoom +', self)
        zoomAction.setShortcut('Ctrl+Z')
        zoomAction.setIconText("Zoom in")
        zoomAction.triggered.connect(self.zoom)
        backAction = QtGui.QAction(QtGui.QIcon('icone/zoom_out'), 'Zoom -', self)
        backAction.setShortcut('Ctrl+B')
        backAction.setIconText("Zoon out")
        backAction.triggered.connect(self.back)
        divideAction = QtGui.QAction(QtGui.QIcon('icone/split'), 'Split', self)
        divideAction.setShortcut('Ctrl+D')
        divideAction.setIconText("Split")
        divideAction.triggered.connect(self.divideCluster)

        toolbar = self.addToolBar('Clustering tool')
        toolbar.addAction(saveAction)
        toolbar.addAction(zoomAction)
        toolbar.addAction(backAction)
        toolbar.addAction(divideAction)
        toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)

        self.line_2 = QtGui.QFrame(self.centralwidget)
        self.line_2.setFrameShape(QtGui.QFrame.VLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.gridLayout.addWidget(self.line_2, 2, 2, 9, 1)
        self.lbl = QtGui.QLabel(self.centralwidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lbl.sizePolicy().hasHeightForWidth())

        self.lbl.setSizePolicy(sizePolicy)
        self.lbl.setFrameShape(QtGui.QFrame.Panel)
        self.lbl.setObjectName(_fromUtf8("lbl"))
        self.gridLayout.addWidget(self.lbl, 2, 1, 9, 1)

        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 3, 4, 1, 1)

        self.lbl1 = QtGui.QLabel(self.centralwidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lbl1.sizePolicy().hasHeightForWidth())
        self.lbl1.setSizePolicy(sizePolicy)
        self.lbl1.setFrameShape(QtGui.QFrame.Box)
        self.lbl1.setObjectName(_fromUtf8("lbl1"))
        self.gridLayout.addWidget(self.lbl1, 2, 0, 9, 1)

        self.figure1 = plt.figure()
        self.canvas1 = FigureCanvas(self.figure1)
        self.gridLayout.addWidget(self.canvas1, 2, 0, 9, 1)

        self.figure2 = plt.figure()
        self.canvas2 = FigureCanvas(self.figure2)
        plt.text(0.25,0.5,'<true segmented image>',fontsize=20,fontstyle='italic', color="Grey")
        plt.axis('off')
        self.gridLayout.addWidget(self.canvas2, 2, 1, 9, 1)

        self.textEdit = QtGui.QTextEdit(self.centralwidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.textEdit.sizePolicy().hasHeightForWidth())
        self.textEdit.setSizePolicy(sizePolicy)
        self.textEdit.setContextMenuPolicy(QtCore.Qt.PreventContextMenu)
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName(_fromUtf8("textEdit"))
        self.gridLayout.addWidget(self.textEdit, 4, 4, 1, 3)
        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 5, 4, 1, 3)
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 2, 4, 1, 1, QtCore.Qt.AlignHCenter)
        self.label_4 = QtGui.QLabel(self.centralwidget)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 7, 4, 1, 1)
        self.textEdit1 = QtGui.QTextEdit(self.centralwidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.textEdit1.sizePolicy().hasHeightForWidth())
        self.textEdit1.setSizePolicy(sizePolicy)
        self.textEdit1.setReadOnly(True)
        self.textEdit1.setObjectName(_fromUtf8("textEdit1"))
        self.gridLayout.addWidget(self.textEdit1, 9, 4, 1, 3)
        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setMinimumSize(QtCore.QSize(70, 21))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 8, 4, 1, 1, QtCore.Qt.AlignHCenter)
        self.toolButton = QtGui.QToolButton(self.centralwidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton.sizePolicy().hasHeightForWidth())
        self.toolButton.setSizePolicy(sizePolicy)
        self.toolButton.setMinimumSize(QtCore.QSize(32, 27))
        self.toolButton.setObjectName(_fromUtf8("toolButton"))
        self.gridLayout.addWidget(self.toolButton, 8, 5, 1, 1)

        self.toolbar = NavigationToolbar(self.canvas1, self)
        self.toolbar.hide()

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QObject.connect(self.toolButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.selectImageCluster)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("Window", "Clustering Result", None))
        self.label_3.setText(_translate("Window", "<html><head/><body><p><span style=\" font-size:10pt;\">- Internal</span></p></body></html>", None))
        self.label.setText(_translate("Window", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-style:italic;\">Evaluation Metrics</span></p></body></html>", None))
        self.label_4.setText(_translate("Window", "<html><head/><body><p><span style=\" font-size:10pt;\">-  External</span></p></body></html>", None))
        self.label_2.setText(_translate("Window", "Select image", None))
        self.toolButton.setText(_translate("Window", "...", None))

    def save(self):
        self.toolbar.save_figure()

    def back(self):
        self.toolbar.back()

    def zoom(self):
        self.toolbar.zoom()

    def divideCluster(self):
        image = cv2.imread("../Progetto Tesi/output/temp.png")

        # Convert BGR to HSV
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        if(self.nK==2):
            lower_blue = np.array([110,50,50])
            upper_blue = np.array([130,255,255])

            lower_red = np.array([0,100,50])
            upper_red = np.array([0,255,255])

            # Threshold the HSV image to get only blue colors
            blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
            red_mask = cv2.inRange(hsv, lower_red, upper_red)

            # Bitwise-AND mask and original image
            res1 = cv2.bitwise_and(image,image, mask= blue_mask)
            res2 = cv2.bitwise_and(image,image, mask= red_mask)

            cv2.imshow("Clustering section", np.vstack([np.hstack([res1, res2])]))

            cv2.waitKey(0)

        if(self.nK==3):
            lower_blue = np.array([110,50,50])
            upper_blue = np.array([130,255,255])

            lower_red = np.array([0,100,50])
            upper_red = np.array([0,255,255])

            lower_green = np.array([50, 50, 120])
            upper_green = np.array([70, 255, 255])

            # Threshold the HSV image to get only blue colors
            blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
            green_mask = cv2.inRange(hsv, lower_green, upper_green)
            red_mask = cv2.inRange(hsv, lower_red, upper_red)

            # Bitwise-AND mask and original image
            res1 = cv2.bitwise_and(image,image, mask= blue_mask)
            res2 = cv2.bitwise_and(image,image, mask= red_mask)
            res3 = cv2.bitwise_and(image,image, mask= green_mask)

            cv2.imshow("image", np.vstack([np.hstack([res1, res2, res3])]))

            cv2.waitKey(0)

        if(self.nK==4):
            lower_blue = np.array([110,50,50])
            upper_blue = np.array([130,255,255])

            lower_red = np.array([0,100,50])
            upper_red = np.array([0,255,255])

            lower_yellow = np.array([20, 100, 100])
            upper_yellow = np.array([50, 255, 255])

            lower_light_blue = np.array([90,50,50])
            upper_light_blue = np.array([110,255,255])

            # Threshold the HSV image to get only blue colors
            blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
            green_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
            red_mask = cv2.inRange(hsv, lower_red, upper_red)
            lightblue_mask = cv2.inRange(hsv, lower_light_blue, upper_light_blue)

            # Bitwise-AND mask and original image
            res1 = cv2.bitwise_and(image,image, mask= blue_mask)
            res2 = cv2.bitwise_and(image,image, mask= red_mask)
            res3 = cv2.bitwise_and(image,image, mask= green_mask)
            res4 = cv2.bitwise_and(image,image, mask= lightblue_mask)

            cv2.imshow("images", np.hstack([res1, res2, res3, res4]))

            cv2.waitKey(0)

        if(self.nK==5):
            lower_blue = np.array([110,50,50])
            upper_blue = np.array([130,255,255])

            lower_red = np.array([0,100,50])
            upper_red = np.array([10,255,255])

            lower_green = np.array([50, 50, 120])
            upper_green = np.array([70, 255, 255])

            lower_light_blue = np.array([100,50,50])
            upper_light_blue = np.array([110,255,255])

            lower_arancio = np.array([10,100,50])
            upper_arancio = np.array([30,255,255])

            # Threshold the HSV image to get only blue colors
            blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
            green_mask = cv2.inRange(hsv, lower_green, upper_green)
            red_mask = cv2.inRange(hsv, lower_red, upper_red)
            arancio_mask = cv2.inRange(hsv, lower_arancio, upper_arancio)
            lightblue_mask = cv2.inRange(hsv, lower_light_blue, upper_light_blue)

            # Bitwise-AND mask and original image
            res1 = cv2.bitwise_and(image,image, mask= blue_mask)
            res2 = cv2.bitwise_and(image,image, mask= red_mask)
            res3 = cv2.bitwise_and(image,image, mask= green_mask)
            res4 = cv2.bitwise_and(image,image, mask= lightblue_mask)
            res5 = cv2.bitwise_and(image,image, mask= arancio_mask)

            #cv2.imshow("images", np.hstack([image, res1, res2, res3, res4, res5]))

            cv2.imshow("image", np.vstack([np.hstack([res1, res2, res3, res4, res5])]))

            cv2.waitKey(0)

        if(self.nK>5):
            QtGui.QMessageBox.critical(self, "Error", "The number of clusters is high!", QtGui.QMessageBox.Ok)


