from Clustering import Clustering
import numpy as np

class KMeans(Clustering):

    def __init__(self, img, c, maxIterations, e, errorType):
        """Costruttore. Richiama il costruttore di Clustering.

            :param img: np.array
                matrice dei pixel dell'immagine da clusterizzare
            :param c: int
                numero di cluster
            :param maxIterations: int
                numero massimo di iterazioni dell'algoritmo
            :param e: float
                errore minimo.
            :param errorType: int
                tipo di errore
        """

        Clustering.__init__(self, img, c, maxIterations, e, errorType) # Chiama costruttore sovraclasse


    def calculateMembership(self):
        """Override. Calcola la matrice di membership a partire dai valori dei centroidi."""

        # Crea un nuovo oggetto matrice membership
        membership = [ [[ 0 for k in range(self.c) ] for h in range(self.height) ] for w in range(self.width) ]
        membership = np.array(membership)

        for h in range(self.height):
            for w in range(self.width):
                # Prende un pixel
                aPixel = self.img[w][h]

                # Trova la distanza tra un pixel e il cluster k-esimo
                distanceMin = self.calcDistance(aPixel, self.centroids[0])
                indexMin = 0
                for k in range(self.c):
                    distance = self.calcDistance(aPixel, self.centroids[k])
                    # Trova distanza minima
                    if (distance < distanceMin):
                        distanceMin = distance
                        indexMin = k

                # Membership = 1 per il cluster piu' vicino
                membership[w][h][indexMin] = 1

        self.membership = membership

    def calculateClusterCenters(self):
        """Override. Calcola i centroidi a partire dalla matrice di membership."""

        for k in range(self.c):
            top = 0.0
            bottom = 0.0

            for h in range(self.height):
                for w in range(self.width):

                    # Prende un pixel
                    aPixel = self.img[w][h]

                    # Top
                    top += np.array(self.membership[w][h][k] * aPixel)

                    # Bottom
                    bottom += np.array(self.membership[w][h][k])

            self.centroids[k] = top/bottom

        self.centroids = self.sort(self.centroids)


    def calculateObjectiveFunction(self):
        """
        Calcola il valore della funzione obiettivo.

        :return: sum: float
            il valore della funzione obiettivo
        """

        sum = 0.0

        for h in range(self.height):
            for w in range(self.width):
                # Prende un pixel
                aPixel = self.img[w][h]

                # Trova la distanza tra un pixel e il cluster k-esimo
                for k in range(self.c):
                    distance = self.calcSquaredDistance(aPixel, self.centroids[k])
                    sum += distance * self.membership[w][h][k]

        return sum
