import numpy as np
from Clustering import Clustering

class FCM(Clustering):

    """Implementa l'algoritmo fuzzy c-means"""

    def __init__(self, img, c, maxIterations, m, e, errorType):
        """Costruttore. Richiama il costruttore di Clustering.

            :param img: np.array
                matrice dei pixel dell'immagine da clusterizzare
            :param c: int
                numero di cluster
            :param maxIterations: int
                numero massimo di iterazioni dell'algoritmo
            :param m: float
                "fuzzyness" dell'algoritmo
            :param e: float
                errore minimo.
            :param errorType: int
                tipo di errore
        """

        self.m = m

        Clustering.__init__(self, img, c, maxIterations, e, errorType) # Chiama costruttore sovraclasse


    def calculateMembership(self):
        """Override. Calcola la matrice di membership a partire dai valori dei centroidi."""

        # Crea un nuovo oggetto matrice membership
        self.membership = [ [[ 0.0 for k in range(self.c) ] for h in range(self.height) ] for w in range(self.width) ]
        self.membership = np.array(self.membership)

        # Per ogni cluster e ogni data point
        for k in range(self.c):
            for h in range(self.height):
                for w in range(self.width):

                    # Prende un pixel
                    aPixel = self.img[w][h]

                    # Distanza tra un pixel e il cluster k-esimo
                    top = self.calcDistance(aPixel, self.centroids[k])

                    # Bottom e' la somma delle distanze da questo data point a tutti i centroidi
                    sumTerms = 0.0

                    for ck in range(self.c):
                        thisDistance = self.calcDistance(aPixel, self.centroids[ck])
                        sumTerms += pow((top / thisDistance),(2.0 / (self.m - 1.0)))

                    self.membership[w][h][k] = (1.0 / sumTerms)

                    #print (self.membership[w][h][k])

    def calculateClusterCenters(self):
        """Override. Calcola i centroidi a partire dalla matrice di membership."""

        for b in range(self.nChannels):
            for k in range(self.c):
                top = 0.0
                bottom = 0.0

                for h in range(self.height):
                    for w in range(self.width):
                        membm = pow(self.membership[w][h][k], self.m)
                        top += membm * self.img[w][h][b] # Numeratore
                        bottom += membm # Denominatore

                self.centroids[k][b] = top / bottom
        #print(self.centroids)


    def calculateObjectiveFunction(self):
        """Override. Calcola il valore della funzione obiettivo di FCM.

            :returns: j:float
                il valore della funzione obiettivo.
        """

        j = 0.0

        for h in range(self.height):
            for w in range(self.width):
                aPixel = [ 0.0 for i in range(self.nChannels) ]

                # Prende il pixel corrente
                for b in range(self.nChannels):

                    aPixel[b] = self.img[w][h][b]

                # Calcola distanza tra un pixel e tutti i centroidi
                for k in range(self.c):
                    distancePixelToCluster = self.calcDistance(np.array(aPixel),np.array(self.centroids[k]))
                    #distancePixelToCluster = self.calcDistance(aPixel,self.centroids[k])
                    j += distancePixelToCluster * pow(self.membership[w][h][k], self.m)
        return j



