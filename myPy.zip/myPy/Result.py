from design2 import *
from ImageUtils import *
from Metrics import *
import numpy as np
import sys
import os.path


class Result(QtGui.QMainWindow, Ui_Window):
      def __init__(self, parent=None):
            QtGui.QWidget.__init__(self, parent)
            self.setupUi(self)

      def main(self):
            Result().main()

      def numCluster(self,k):
            self.nK=k

            return self.nK

      def setMetrics(self,sse,xie,entropy_memb):
            self.sse = sse
            self.sse = '%.4f'%self.sse
            self.xie = xie
            self.xie = '%.4f'%self.xie
            self.entropy = entropy_memb
            self.entropy = '%.4f'%self.entropy

            self.stamp()

            return self.sse, self.xie, self.entropy

      #stampa i metodi di valutazione esterni e interni
      def stamp(self):
            self.textEdit.setText("\n - SEE -> " + str(self.sse) + "\n\n - Xie Beni -> " + str(self.xie) +
                                  "\n\n - Entropy membership -> " + str(self.entropy))

            self.textEdit1.setText("<html><head/><body><p align=\"center\"><span style=\" font-style:italic;\"> a segmented image is required to compute external metrics </span></p></body></html>")

      def stamp1(self):
            self.textEdit1.clear()
            self.textEdit1.setText("\n - Entropy -> "+str(self.entropy_ext) + "\n\n - Purity -> "+str(self.purity) +
                                   "\n\n - Accuracy -> " + str(self.accuracy) + "\n\n - Precision -> " + str(self.precision) +
                                   "\n\n - Recall -> " + str(self.recall) + "\n\n - F-score -> " + str(self.fscore) +
                                   "\n\n - Jaccard index -> " + str(self.jaccard) +
                                   "\n\n\n - Total entropy -> " + str(self.totEntropy) +
                                   "\n\n - Total purity -> " + str(self.totPurity))

      def showImage(self, codeim, im, filename):
            self.code = imresize(codeim, im.shape[:2]) # Ridimensiona l'immagine
            plt.figure(self.figure1.number)
            plt.imshow(self.code)
            plt.axis("off")
            plt.suptitle('Clustered Image: < ' + filename + ' >', fontsize=16, fontweight='bold')
            return self.code

      def selectImageCluster(self):
            self.canvas2.figure.clear()
            fileName = QtGui.QFileDialog.getOpenFileName(self, "Open Image File", QtCore.QDir.homePath(), "Image Files (*)")

            if fileName:
                  file=fileName.toLocal8Bit().data()
                  f = os.path.basename(file)
                  self.image = np.array(Image.open(file))
                  plt.figure(self.figure2.number)
                  self.img= plt.imshow(self.image)
                  plt.axis("off")
                  plt.suptitle('Correctly clustered image: < ' + f + ' >', fontsize=16, fontweight='bold')
                  self.img.figure.canvas.draw()

            corrSegmentedImage, nClasses = ImageUtils.convertImageMatrixToLabelledMatrix(self.image)

            self.corrSegmentedImage=corrSegmentedImage
            self.nClasses=nClasses

            self.getMetrics(segmentedImage=self.res, corrSegmentedImage=self.corrSegmentedImage,
                            k=self.k, nClasses=self.nClasses, clusteringResult=self.clusteringResult)

            zoomAction1 = QtGui.QAction(QtGui.QIcon('icone/zoom_in'), 'Zoom +', self)
            zoomAction1.setShortcut('Ctrl+Z')
            zoomAction1.setIconText("Zoom in")
            zoomAction1.triggered.connect(self.zoom1)
            backAction1 = QtGui.QAction(QtGui.QIcon('icone/zoom_out'), 'Zoom -', self)
            backAction1.setShortcut('Ctrl+B')
            backAction1.setIconText("Zoon out")
            backAction1.triggered.connect(self.back1)

            toolbar1 = self.addToolBar('Correctly tool')
            toolbar1.addAction(zoomAction1)
            toolbar1.addAction(backAction1)
            toolbar1.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)

            self.toolbar1 = NavigationToolbar(self.canvas2, self)
            self.toolbar1.hide()

            return self.image

      def setMetrics1(self,k,res,clusteringResult):
            self.k=k
            self.res=res
            self.clusteringResult=clusteringResult

            return self.k, self.res, self.clusteringResult

      def getMetrics(self, segmentedImage, corrSegmentedImage, k, nClasses, clusteringResult):
            acc = Metrics(segmentedImage, corrSegmentedImage, k, nClasses, clusteringResult)

            # Mostra accuratezza per classe (Indice di Jaccard)
            self.jaccard = acc.calculateJaccardIndex()
            self.entropy_ext = acc.calculateEntropy()
            self.purity = acc.calculatePurity()
            self.precision = acc.calculatePrecision()
            self.recall = acc.calculateRecall()
            self.fscore = acc.calculateFScore()
            self.accuracy = acc.calculateAccuracy()
            self.accuracy = '%.4f'%self.accuracy
            self.totEntropy = acc.calculateTotalEntropy()
            self.totEntropy = '%.4f'%self.totEntropy
            self.totPurity = acc.calculateTotalPurity()
            self.totPurity = '%.4f'%self.totPurity

            self.stamp1()

      def zoom1(self):
            self.toolbar1.zoom()

      def back1(self):
            self.toolbar1.back()

if __name__=='__main__':
      app = QtGui.QApplication(sys.argv)
      form = Result()
      form.main()
      app.exec_()
