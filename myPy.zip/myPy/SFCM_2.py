from SFCM_1 import SFCM_1

class SFCM_2(SFCM_1):

    # Calcola mediana
    def calculateFilteredPixel(self, w, h):
        # Lista data point della finestra
        list = []

        # Calcola media finestra (per ciascun canale)
        window = self.findWindow(w, h, self.dim)
        for i in range(len(window)):
            x = window[i][0]
            y = window[i][1]
            list.append(self.img[x][y])

        list = self.sort(list)

        lun = len(list)
        if ((lun % 2) == 0): # Caso pari
            pos = lun / 2
            median = (list[pos] + list[pos + 1]) / 2.0
        else: # Caso dispari
            pos = int(lun / 2)
            median = list[pos]

        return median